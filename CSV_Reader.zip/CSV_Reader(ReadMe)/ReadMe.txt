Please change the command line path to your own path to read the TestData.csv
This is found under solution properties -> Debug