using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using ScoreAPI;

var builder = WebApplication.CreateBuilder(args);

var config = builder.Configuration;

builder.Services.AddDbContext<ScoreDBContext>(options =>
    options.UseSqlite(@"Data Source=C:\Users\tahir\source\repos\CSV_Reader\bin\Debug\net9.0\TestData.db"));



// Add services to the container.
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer(); // Required for Swagger metadata
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new() { Title = "Score API", Version = "v1" });
});

var app = builder.Build();




// Use Swashbuckle only in Development environment
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage(); // For detailed exception page in dev
    app.UseSwagger();                // Enable middleware to serve swagger.json
    app.UseSwaggerUI(c =>            // Enable middleware for Swagger UI at /swagger
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "Score API V1");
    });
   
}



app.UseHttpsRedirection();


//The order of the following 4 lines is important
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();

app.Run();