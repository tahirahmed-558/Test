﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace ScoreAPI
{
    public class ScoreDBContext : DbContext
    {

        public ScoreDBContext(DbContextOptions<ScoreDBContext> options) : base(options) { }
        public DbSet<Scores> Scores { get; set; }

    }

}
