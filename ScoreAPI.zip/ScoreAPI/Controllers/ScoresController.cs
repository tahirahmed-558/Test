﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ScoreAPI
{
    [Route("v1/")]
    [ApiController]
    public class ScoresController : ControllerBase
    {
        private readonly ScoreDBContext _context;

        //Constructor
        public ScoresController(ScoreDBContext context)
        {
            _context = context;
        }


        [HttpPost]
        [Route("PostScore")]
        [ApiExplorerSettings(GroupName = "v1")]  // Ensures Swagger includes it in v1 doc
        [ProducesResponseType(201)]  // Documents 201 Created response in Swagger
        [ProducesResponseType(400)]  // Documents Bad Request for validation errors
        public async Task<IActionResult> PostScore(Scores score)
        {
            try
            {
                _context.Scores.Add(score);
                await _context.SaveChangesAsync();
                return CreatedAtAction(nameof(GetScore), new { person = score.Name }, score);
            }
            catch (Exception)
            {
                throw;
            }

        }

        [HttpGet]
        [Route("GetScore")]
        [ApiExplorerSettings(GroupName = "v1")]  // Ensures Swagger includes it in v1 doc
        [ProducesResponseType(201)]  // Documents 201 Created response in Swagger
        [ProducesResponseType(400)]  // Documents Bad Request for validation errors
        public async Task<ActionResult<Scores>> GetScore(string person)
        {
            try
            {

                var score = await _context.Scores.FirstOrDefaultAsync(s => s.Name.ToLower() == person.ToLower());
                return score == null ? NotFound() : score;

            }
            catch (Exception)
            {
                throw;
            }
        }

        [HttpGet]
        [Route("GetTopScores")]
        [ApiExplorerSettings(GroupName = "v1")]  // Ensures Swagger includes it in v1 doc
        [ProducesResponseType(201)]  // Documents 201 Created response in Swagger
        [ProducesResponseType(400)]  // Documents Bad Request for validation errors
        public async Task<ActionResult<IEnumerable<Scores>>> GetTopScores()
        {
            try
            {
                var maxScore = await _context.Scores.MaxAsync(s => s.Score);
                var topScores = await _context.Scores.Where(s => s.Score == maxScore)
                    .OrderBy(s => s.Name)
                    .ToListAsync();
                return Ok(topScores);
            }
            catch (Exception)
            {
                throw;
            }

        }

    }
}

