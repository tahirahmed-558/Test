﻿using SQLite;
using System.Data.SqlTypes;
using System.Text.Json.Serialization;

namespace ScoreAPI
{
    public class Scores
    {
        [SQLite.PrimaryKey, AutoIncrement]
        [JsonIgnore]
        public int Id { get; set; }
        public string? Name { get; set; }
      
        public int Score { get; set; }
    }
}
