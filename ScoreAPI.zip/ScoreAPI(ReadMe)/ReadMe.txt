Please change the location of the database path to the path where the database is created for e.g CSV_Reader bin folder, so that the rest api can 
read the database.